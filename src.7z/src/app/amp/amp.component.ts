import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amp',
  templateUrl: './amp.component.html',
  styleUrls: ['./amp.component.css']
})
export class AmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
