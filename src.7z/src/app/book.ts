export class Book {
  id: number;
  title: string;
  cost: number;
  author: string;
}
