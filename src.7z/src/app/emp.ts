export class Emp {
  eid: number;
  ename: string;
  salary: number;
  dept: string;
  imgurl: string;
}
