export class Product {
  pid: number;
  pname: string;
  price: number;
  cat: string;
  imgurl: string;
}
